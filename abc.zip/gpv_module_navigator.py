import asyncio
import re
from pathlib import Path
from playwright.async_api import async_playwright
from config import Config
from Bot_GPV.ai_film_factory.auth_machine import AuthMachine
from Bot_GPV.core.gpv_form_miner import FormMiner

class ModuleNavigator:
    def __init__(self):
        self.auth = AuthMachine()
        self.target_domain = Config.TARGET_DOMAIN.replace("https://", "").replace("http://", "").split('/')[0]

    async def run_task(self, mode="HOME_SCAN", module_url=None, project_folder=None, modul_name=None):
        """
        Hệ điều hành trung tâm: Có log debug chi tiết từng bước di chuyển.
        """
        m_name = modul_name if modul_name else "Chung"
        results = {}
        print(f"\n{'='*60}")
        print(f"🤖 [ENGINE START] Chế độ: {mode} | Đối tượng: {m_name}")
        print(f"{'='*60}")

        base_url = str(Config.TARGET_DOMAIN).strip().rstrip('/')
        if not base_url.startswith("http"):
            base_url = f"https://{base_url}"

        async with async_playwright() as p:
            print(f"🌐 1. Đang khởi tạo trình duyệt Chromium...")
            browser = await p.chromium.launch(headless=False, slow_mo=100)
            context = await browser.new_context(viewport={'width': 1920, 'height': 1080})
            page = await context.new_page()

            try:
                # 2. LOGIN
                print(f"🔑 2. Đang yêu cầu AuthMachine xử lý đăng nhập...")
                if await self.auth.login(page):
                    print(f"✅ Đăng nhập thành công! Đang ở: {page.url}")
                    
                    # --- CHẾ ĐỘ 1: DEEP_SCAN ---
                    if mode == "DEEP_SCAN" and module_url:
                        final_module_url = module_url if module_url.startswith("http") else f"{base_url}/{module_url.lstrip('/')}"
                        
                        print(f"🛰️ 3. [DeepScan] Mục tiêu: {final_module_url}")
                        
                        # Điều hướng
                        print(f"🚚 Đang di chuyển đến module cụ thể...")
                        await page.goto(final_module_url, wait_until="domcontentloaded")
                        
                        # Kiểm tra Sidebar
                        try:
                            print(f"⏳ Đang đợi Sidebar (GPV) hiển thị...")
                            await page.wait_for_selector('.minimal__nav__li', timeout=3000)
                            print(f"➡️ Sidebar đã sẵn sàng.")
                        except:
                            print(f"⚠️ Cảnh báo: Sidebar không xuất hiện, có thể giao diện khác biệt.")

                        await page.wait_for_timeout(1000)
                        await page.keyboard.press("Escape") 

                        # QUÉT SIDEBAR
                        print(f"🌿 4. Đang phân tích cấu trúc Menu (Sidebar)...")
                        sidebar_results = await self._extract_sidebar_deep(page, m_name)
                        
                        # KÍCH HOẠT THỢ ĐÀO
                        print(f"⛏️ 5. BÀN GIAO CHO FORMMINER...")
                        miner = FormMiner(page, config_class=Config)

                        # VŨ CHÚ Ý: Nếu sidebar_results trả về danh sách các menu con, 
                        # ta sẽ cho nó click từng cái rồi mới 'start_mining'
                        
                        all_module_data = []
                        
                        # Giả sử sidebar_results['menus'] chứa danh sách các menu con đã tìm thấy
                        if sidebar_results and 'menus' in sidebar_results:
                            for menu in sidebar_results['menus']:
                                print(f"🖱️ Đang click mở Menu: {menu['name']}")
                                try:
                                    # Click vào menu con trên giao diện thực
                                    await page.click(menu['selector'])
                                    await page.wait_for_load_state("networkidle")
                                    await page.wait_for_timeout(1500) # Đợi tí cho bảng vẽ ra
                                    
                                    # Sau khi click, giao diện đã hiện ra -> Gọi Thợ Đào ngay tại đây
                                    print(f"🕵️ Nội soi giao diện: {menu['name']}")
                                    mining_results = await miner.start_mining(page.url, menu['name'])
                                    all_module_data.append(mining_results)
                                except Exception as e:
                                    print(f"⚠️ Không thể mở menu {menu['name']}: {e}")
                        else:
                            # Nếu không có danh sách menu con, đào trang hiện tại (mặc định)
                            mining_results = await miner.start_mining(final_module_url, m_name)
                            all_module_data.append(mining_results)

                        results = {
                            "module_info": sidebar_results,
                            "ui_metadata": all_module_data, # Chứa dữ liệu của tất cả các trang đã click
                            "scan_time": Config.get_current_time()
                        }
                    # --- CHẾ ĐỘ 2: HOME_SCAN ---
                    elif mode == "HOME_SCAN":
                        print("🏠 3. [HomeScan] Đang quét danh sách module ngoài trang chủ...")
                        await page.wait_for_timeout(2000)
                        results = await self._extract_home_modules(page)
                        print(f"📦 Đã tìm thấy {len(results) if results else 0} module.")

                    # --- LƯU SCREENSHOT ---
                    print(f"📸 6. Đang chụp ảnh bằng chứng (Screenshot)...")
                    asset_path = Config.get_path(m_name, asset_type="assets")
                    save_path = asset_path / f"last_{mode.lower()}.jpg"
                    await page.screenshot(path=str(save_path), quality=90)
                    print(f"🖼️ Đã lưu tại: {save_path}")

                else:
                    print("❌ [LỖI] AuthMachine thất bại. Không thể tiến vào hệ thống.")

            except Exception as e:
                print(f"💥 [CRITICAL ERROR]: {str(e)}")
                import traceback
                traceback.print_exc() # In chi tiết lỗi dòng nào luôn
            
            finally:
                print(f"\n🏁 [TERMINATED] Đang đóng trình duyệt và dọn dẹp tài nguyên.")
                await browser.close()
                print(f"{'='*60}\n")

        return results

    async def _extract_sidebar_deep(self, page, modul_name):
        prefix = modul_name if modul_name else "Chung"
        
        # 1. Lấy đường dẫn file JS từ Config
        # Giả sử Config.get_javascript_path() trả về đối tượng Path
        js_path = Config.get_javascript_path("sidebar_script.js")

        if not js_path.exists():
            print(f"❌ Không tìm thấy script tại: {js_path}")
            return {}

        print(f"✅ Đã kết nối script: {js_path.name}")

        try:
            # 2. Đọc và Bơm code vào trang
            js_code = js_path.read_text(encoding='utf-8')
            await page.evaluate(js_code)

            # 3. Thực thi: Mở menu và Đợi render
            # Tao khuyên nên gom expandAll và extractData thành 1 dòng evaluate 
            # để tránh mất context nếu trang bị reload nhẹ
            await page.evaluate('window.sidebarScraper.expandAll()')
            
            # Đợi thêm 1 chút sau khi expand để đảm bảo DOM đã ổn định
            await page.wait_for_timeout(500)
            
            # 4. Lấy kết quả
            results = await page.evaluate(f'window.sidebarScraper.extractData("{prefix}")')
            return results

        except Exception as e:
            print(f"❌ Lỗi khi thực thi JS Scraper: {e}")
            return {}
    
    async def _extract_home_modules(self, page):
        """
        Logic Cấp 1: Quét xuyên tất cả Iframe để tìm Module.
        """
        all_links = []
        # Đổi thành get_javascript_path để chắc chắn nhận về đối tượng Path
        js_file_path = Config.get_javascript_path("extract_modules.js")
        
        if not js_file_path.exists():
            print(f"❌ Không tìm thấy script: {js_file_path}")
            return []

        # Chỉ đọc text khi chắc chắn file tồn tại
        js_script = js_file_path.read_text(encoding='utf-8')
        
        frames = page.frames
        print(f"🕵️ Đang quét trên {len(frames)} frames...")

        for frame in frames:
            try:
                raw = await frame.evaluate(js_script)
                if raw and isinstance(raw, list):
                    all_links.extend(raw)
            except:
                continue 

        unique = {}
        exclude_keywords = ["đăng xuất", "cài đặt", "hướng dẫn", "thông báo", "profile", "user", "trang chủ", "login"]
        
        for m in all_links:
            # Check kỹ dữ liệu đầu vào từ JS
            if not m or 'text' not in m or 'href' not in m: continue
            
            text_clean = re.sub(r'[•○+►]', '', str(m['text'])).strip()
            href = str(m['href'])
            
            if len(text_clean) > 2:
                # Kiểm tra domain thông minh hơn
                is_module = '/module/' in href.lower()
                is_internal = self.target_domain.lower() in href.lower() or href.startswith('/')
                
                if (is_module or is_internal) and not any(k in text_clean.lower() for k in exclude_keywords):
                    if text_clean not in unique:
                        # Chuẩn hóa URL
                        if href.startswith('/'):
                            full_href = f"https://{self.target_domain.strip('/')}{href}"
                        else:
                            full_href = href
                        unique[text_clean] = {"text": text_clean, "href": full_href}

        print(f"✅ Đã tìm thấy {len(unique)} Module khả dụng.")
        return list(unique.values())

# Thêm hàm để nó thực sự click vào menu cha, con
async def navigate_and_mine(self, menu_structure):
    """
    menu_structure: Dữ liệu từ sidebar_script.js trả về
    Ví dụ: [{'parent': 'Danh mục', 'subs': [{'text': 'Khách hàng', 'selector': '...'}]}]
    """
    for parent in menu_structure:
        print(f"📂 Đang mở menu cha: {parent['text']}")
        # Click mở menu cha nếu nó chưa mở
        await self.page.click(parent['selector'])
        await self.page.wait_for_timeout(500)

        for sub in parent['subs']:
            print(f"  ∟ 🖱️ Đang vào menu con: {sub['text']}")
            await self.page.click(sub['selector'])
            
            # ĐỢI GIAO DIỆN LOAD (Cực kỳ quan trọng)
            await self.page.wait_for_load_state("networkidle")
            await self.page.wait_for_timeout(2000) 

            # BẮT ĐẦU ĐÀO TẠI ĐÂY
            print(f"    🔎 Đang nội soi giao diện: {sub['text']}")
            await self.start_mining(self.page.url, sub['text'])